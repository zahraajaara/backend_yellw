﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YellowKalam.Api.Data;
using YellowKalam.Api.Models;

namespace YellowKalam.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]   // → /api/Ministry
    public class MinistryController : ControllerBase
    {
        private readonly YellowKalamContext _context;

        public MinistryController(YellowKalamContext context)
        {
            _context = context;
        }

        // GET: api/Ministry   (all)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Ministry>>> GetMinistries()
        {
            return await _context.Ministries
                .AsNoTracking()
                .OrderBy(m => m.MinistryId)
                .ToListAsync();
        }

        // GET: api/Ministry/5
        [HttpGet("{id:int}")]
        public async Task<ActionResult<Ministry>> GetMinistry(int id)
        {
            var item = await _context.Ministries
                .AsNoTracking()
                .FirstOrDefaultAsync(m => m.MinistryId == id);

            if (item == null)
                return NotFound();

            return item;
        }
    }
}
