﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YellowKalam.Api.Data;
using YellowKalam.Api.Models;

namespace YellowKalam.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]   // → /api/Municipality
    public class MunicipalityController : ControllerBase
    {
        private readonly YellowKalamContext _context;

        public MunicipalityController(YellowKalamContext context)
        {
            _context = context;
        }

        // GET: api/Municipality   (all)
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Municipality>>> GetMunicipalities()
        {
            return await _context.Municipalities
                .AsNoTracking()
                .OrderBy(m => m.MunicipalityId)
                .ToListAsync();
        }

        // GET: api/Municipality/5
        [HttpGet("{id:int}")]
        public async Task<ActionResult<Municipality>> GetMunicipality(int id)
        {
            var item = await _context.Municipalities
                .AsNoTracking()
                .FirstOrDefaultAsync(m => m.MunicipalityId == id);

            if (item == null)
                return NotFound();

            return item;
        }
    }
}
